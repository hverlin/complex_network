# -*- coding: utf-8 -*-
"""
Programming template for CS-E5740 Complex Networks problem 3.3 (PageRank)
Written by Onerva Korhonen

Created on Tue Sep  8 10:25:49 2015

@author: aokorhon
"""

import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
import timeit

def pageRank(network, d, n_steps):
    """
    Returns the PageRank value, calculated using a random walker, of each
    node in the network. The random walker teleports to a random node with
    probability 1-d and with probability d picks one of the neighbors of the
    current node.

    Parameters
    -----------
    network : a networkx graph object
    d : damping factor of the simulation
    n_steps : number of steps of the random walker

    Returns
    --------
    page_rank: dictionary of node PageRank values (fraction of time spent in
               each node)
    """
    # Initializing PageRank dictionary:
    pageRank = {}
    print "TODO: write code for calculating PageRank of each node"
    # Use the random walker algorithm.
    # Some pseudocode:
    # 1) Initialize PageRank of of each node to 0
    # 2) Pick a random starting point for the random walker (Hint: np.random.randint)
    # 3) Random walker steps, at each step:
    #   1) Increase the PageRank of current node by 1
    #   2) Check if the random walker will teleport or go to a neighbor
    #   3) Pick the next node either randomly or from the neighbors
    #   4) Update the current node variable to point to the next node
    # 4) Repeat random walker steps 1-4 n_steps times
    # 5) Normalize PageRank by n_steps
    return pageRank
    
def pagerank_poweriter(g,d,iterations):
    """
    Uses the power iteration method to calculate PageRank value for each node
    in the network.
    
    Parameters
    -----------
    g : a networkx graph object
    d : damping factor of the simulation
    n_iterations : number of iterations to perform
    
    Returns
    --------
    pageRank : dict where keys are nodes and values are PageRank values
    """
    pageRank = {}
    print "TODO: write a function for obtaining PageRank by power iteration"
    # Some pseudocode:
    # 1) Create a PageRank dictionary and initialize the PageRank of each node
    #    to 1/n.
    # 2) For each node i, find nodes having directed link to i and calculate
    #    sum(x_j(t-1)/k_j^out) where the sum is across the node's neighbors 
    #    and x_j(t-1) is the PageRank of node  .
    # 3) Update each node's PageRank to (1-d)*1/n + d*sum(x_j(t-1)/k_j^out).
    # 4) Repeat 2-3 n_iterations times.
    return pageRank

def add_colorbar(cvalues, 
                 cmap='OrRd', 
                 cb_ax=None):
    """
    Add a colorbar to the axes.

    Parameters
    ----------
    cvalues : 1D array of floats

    """
    import matplotlib as mpl
    eps = np.maximum(0.0000000001, np.min(cvalues)/1000.)
    vmin=np.min(cvalues) - eps
    vmax=np.max(cvalues)
    norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)
    scm = mpl.cm.ScalarMappable(norm, cmap)
    scm.set_array(cvalues)
    if cb_ax is None:
        plt.colorbar(scm)
    else:
        cb = mpl.colorbar.ColorbarBase(cb_ax, 
                                       cmap=cmap, 
                                       norm=norm, 
                                       orientation='vertical')

def visualize_network(network, 
                      node_positions, 
                      figure_path,
                      cmap='OrRd', 
                      node_size='3000',
                      node_colors=[],
                      with_labels=True,
                      title=""):
    """
    Visualizes the given network using networkx.draw and saves it to the given
    path.

    Parameters
    ----------
    network : a networkx graph object
    node_positions : a list positions of nodes, obtained by e.g. networkx.graphviz_layout
    figure_path : string
    cmap : colormap
    node_size : int
    node_colors : a list of node colors
    with_labels : should node labels be drawn or not, boolean
    title: title of the figure, string
    """
    fig = plt.figure(figsize=(15, 10))
    ax = fig.add_subplot(111)
    if node_colors:
        print "TODO: write code to visualize the networks with nodes" + \
                "colored by PageRank."
        # Hint: use nx.draw and make use of parameters pos, node_color,
        # cmap, node_size and with_labels
        add_colorbar(node_colors)
        ax.set_title(title)
        plt.tight_layout()
    else:
        print "TODO: write code to visualize the networks without node" + \
                "coloring."
        # Hint: use nx.draw and make use of parameters pos, cmap, node_size and
        # with_labels
        ax.set_title(title)
        plt.tight_layout()
    if figure_path is not '':
        plt.savefig(figure_path, 
                    format='pdf', 
                    bbox_inches='tight')

def investigate_d(network, 
                  ds, 
                  colors, 
                  n_steps, 
                  d_figure_path):
    """
    Calculates PageRank at different values of the damping factor d and
    visualizes and saves results for interpretation

    Parameters
    ----------
    network : a NetworkX graph object
    ds : a list of d values
    colors : visualization color for PageRank at each d, must have same length as ds
    n_steps : int; number of steps taken in random walker algorithm
    d_figure_path : string
    """
    fig = plt.figure()
    ax = fig.add_subplot(111)
    print "TODO: write a for loop to obtain node PageRank values at each d" + \
          "and to plot the PageRank."
    # Hint: use zip to loop over ds and colors at once
    ax.set_xlabel(r'Node index')
    ax.set_ylabel(r'PageRank')
    ax.set_title(r'PageRank with different damping factors')
    ax.legend(loc=0)
    plt.tight_layout
    if d_figure_path is not '':
        plt.savefig(d_figure_path, 
                    format='pdf', 
                    bbox_inches='tight')



# This is executed if the file is run from terminal with
# python pagerank.py

if __name__ == '__main__':
    print "TODO: set correct network paths, etc"
    network_path = '' # TODO: replace, set the correct path to the network
    network = nx.DiGraph() # TODO: replace, load the network with with nx.read_edgelist.
                           # Hint: use parameter create_using=nx.DiGraph()

    # Visualization of the model network network (note that spring_layout
    # is intended to be used with undirected networks):
    node_positions = nx.layout.spring_layout(network.to_undirected())
    uncolored_figure_path = '' # TODO: replace: set a correct figure path
    visualize_network(network, 
                      node_positions,  
                      uncolored_figure_path,
                      title='network')
    nodes = network.nodes()
    n_nodes = len(nodes)

    # PageRank with self-written function
    n_steps = 0 # TODO: replace: set a reasonable n_steps
    d = 0 # TODO: replace: set a reasonable d; nx.pagerank uses d = 0.85
    pageRank_rw = pageRank(network, d, n_steps)

    # Visualization of PageRank on network:
    node_colors = [pageRank_rw[node] for node in nodes]
    colored_figure_path = '' # TODO: replace, set a correct path for the colored
                                   # network figure
    visualize_network(network, 
                      node_positions,  
                      colored_figure_path,
                      node_colors=node_colors,
                      title='PageRank random walker')

    # PageRank with networkx:
    pageRank_nx = nx.pagerank(network)

    # Comparison of results from own function and nx.pagerank match:
    pageRank_rw_array = np.zeros(n_nodes)
    pageRank_nx_array = np.zeros(n_nodes)
    for node in nodes:
        pageRank_rw_array[int(node)] = pageRank_rw[node] # ordering dictionary values to node order
        pageRank_nx_array[int(node)] = pageRank_nx[node]
    fig = plt.figure(1)
    ax = fig.add_subplot(111)
    check_figure_path = '' # TODO: replace, set a correct path for the sanity
                           #       check visualization
    plt.plot(range(0, n_nodes), 
             pageRank_rw_array,
             'k+',
             label=r'Random walker')
    plt.plot(range(0, n_nodes), 
             pageRank_nx_array,
             'rx',
             label=r'networkx')
    ax.set_xlabel(r'Node index')
    ax.set_ylabel(r'PageRank')
    ax.set_title(r'PageRank with different methods')
    ax.legend(loc=0)
    plt.tight_layout
    assert check_figure_path is not '', "check definition of check_figure_path"
    plt.savefig(check_figure_path, 
                format='pdf',
                bbox_inches='tight')
    
    # PageRank with power iteration
    n_iterations = 10
    pageRank_pi = pagerank_poweriter(network, d, n_iterations)
    
    # Visualization of PageRank by power iteration on the network
    power_iteration_path = '' # TODO: replace with a correct path
    node_colors = [pageRank_pi[node] for node in nodes]
    visualize_network(network, 
                      node_positions, 
                      power_iteration_path, 
                      node_colors=node_colors,
                      title='PageRank power iteration')
                      
    # Investigating the running time of the power iteration fuction
    num_tests=3
    k5net=nx.DiGraph() # TODO: replace with a test network of suitable size
    result=timeit.timeit(lambda :pagerank_poweriter(k5net,0.85,10),number=num_tests)
    # TODO: Print results: how many seconds were taken for the test network of 
    #       10**4 nodes, how many hours would a 26*10**6 nodes network take?
    
    # Investigating the running time of the random walker function
    n_steps = 0 # TODO: set such number of steps that each node gets visited
                #       on average 1000 times
    result = timeit.timeit(lambda :pageRank(k5net,0.85,n_steps),number=num_tests)
    # TODO: Print results: how many seconds were taken for the test network of 
    #       10**4 nodes, how many hours would a 26*10**6 nodes network take?

    # Investigating effects of d:
    ds = np.arange(0, 1.2, 0.2)
    colors = ['b', 'r', 'g', 'm', 'k', 'c']
    d_figure_path = '' # TODO: replace, set a correct figure path
    investigate_d(network, ds, colors, n_steps, d_figure_path)
    
    # Wikipedia network:
    network_path_wp = '' # TODO: replace, set the correct network path
    network_wp = nx.DiGraph() # TODO: replace with the network loaded with
                                    # nx.read_edgelist.
    pageRank_wp = nx.pagerank(network_wp)
    indegree_wp = network_wp.in_degree()
    outdegree_wp = network_wp.out_degree()
    if pageRank_wp is not {}:
        highest_pr = sorted(pageRank_wp, key=lambda k: pageRank_wp[k])[::-1][0:5]
        print '---Highest PageRank:---'
        for p in highest_pr:
            print pageRank_wp[p], ":", p
    if indegree_wp is not {}:
        highest_id = sorted(indegree_wp, key=lambda k: indegree_wp[k])[::-1][0:5]
        print '---Highest In-degree:---'
        for p in highest_id:
            print indegree_wp[p], ":", p
    if outdegree_wp is not {}:
        highest_od = sorted(outdegree_wp, key=lambda k: outdegree_wp[k])[::-1][0:5]
        print '---Highest Out-degree:---'
        for p in highest_od:
            print outdegree_wp[p], ":", p



