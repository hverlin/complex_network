# -*- coding: utf-8 -*-
"""
Python coding template for CS-E5740 Complex Networks problem 3.3 (Basic
centrality measures).
Written by Onerva Korhonen.

Original example code created on Mon Aug 25 10:23:54 2014.
Modified to create template 20.10.2015.
Template updated 19.10.2016.

@author: aokorhon
"""
import numpy as np
import networkx as nx
import matplotlib.pylab as plt
from matplotlib import gridspec
from colorbar_help import add_colorbar
import pickle

def get_centrality_measures(network, tol):
    """
    Calculates five centrality measures (degree, betweenness, closeness, and
    eigenvector centrality, and k-shell) for the nodes of the given network.

    Parameters
    ----------
    network: networkx.Graph()
    tol: tolerance parameter to calculate eigenvector centrality, float

    Returns
    --------
    [degree, betweenness, closeness, eigenvector_centrality, kshell]: list of
    lists
    """
    degree = []
    betweenness = []
    closeness = []
    eigenvector_centrality = [] # remember to use tol parameter
    kshell = []
    print "TODO: write code for obtaining centrality measures"
    # use NetworkX functions to obtain centrality measure dictionaries
    # sort the dictionary values into arrays in the order given by
    # network.nodes().
    # Hint: make use of get method of dictionaries.
    return [degree, betweenness, closeness, eigenvector_centrality, kshell]

def create_scatter(x_values, y_values, x_label, y_label, labels, markers, figure_path):
    """
    Creates a scatter plot of y_values as a function of x_values. 

    Note that y_values is a list of lists and this function plots the y_values of each list
    against the same x_values.

    Parameters
    ----------
    x_values: np.array
    y_values: list of lists
    x_label: string
    y_label: string
        a generic label of the y axis
    labels: list of strings
        labels of scatter plots
    markers: list of strings
    figure_path: string

    Returns
    -------
    No direct output, saves the scatter plot at given figure_path
    """
    assert len(x_values) > 0, 'Bad input x_values for creating a scatter plot'
    print "TODO: write code function for creating the scatter plot."
    # Remember to save the figure!
    print 'Scatter plot ready!'


def visualize_on_network(network, node_values, coords_path, fig, 
                         titles, figure_path, cmap='OrRd',
                         node_size=50, font_size=8, scale=500):
    """
    Creates visualizations of the network with nodes color coded by each of the
    node values sets.

    Parameters
    ----------
    network: networkx.Graph()
    node_values: list of lists
    coords_path: path to a file containing node coordinates
    fig: matplotlib.pyplot.figure()
    titles: list of strings
    figure_path: string
    cmap: string
    node_size: int
    font_size: int
    scale: int
        used to calculate the spring layout for node positions

    Returns
    -------
    No direct output, saves the network visualizations at given path
    """
    assert len(node_values[0]) > 0, "there should be multiple values per node"

    # This is the grid for 5 pictures
    gs = gridspec.GridSpec(3, 4, width_ratios=(20, 1, 20, 1))
    network_gs_indices = [(0, 0), (0, 2), (1, 0), (1, 2), (2,0)]
    cbar_gs_indices = [(0, 1), (0, 3), (1, 1), (1, 3), (2, 1)]

    # Loading coordinates from the file
    with open(coords_path, 'rb') as f:
        coords = pickle.load(f)

    # Loop over different value sets
    for node_val, title, network_gs_index, cb_gs_index in zip(node_values, 
                                                              titles, 
                                                              network_gs_indices, 
                                                              cbar_gs_indices):
        # Draw the network figure
        ax = plt.subplot(gs[network_gs_index[0], network_gs_index[1]])    
        nx.draw(network, pos=coords, node_color=node_val, cmap=cmap,
                node_size=node_size, font_size=font_size)

        # Draw the colorbar (cb)
        cb_ax = plt.subplot(gs[cb_gs_index[0], cb_gs_index[1]])
        add_colorbar(node_val, cb_ax=cb_ax)

        ax.set_title(title)

    plt.tight_layout()
    plt.savefig(figure_path, format='pdf',
                bbox_inches='tight')
    print 'Network visualizations ready!'


#  This is executed if the file is run from terminal with
# python basic_centrality_measures.py

if __name__=='__main__':
    print "TODO: set locations to files to be read and written, as well as labels"
    # see all places marked with 'replace'
    network_paths = [] # TODO: replace
    coords_paths = [] # TODO: replace
    network_names = ['','','',''] # TODO: replace; these are extensions added to figure file names
    x_label = '' # TODO: replace
    y_label = '' # TODO: replace
    labels = ['','','',''] # TODO: replace
    markers = ['.','x','+','o']
    scatter_base_path = '' # TODO: replace, where to save the scatter
    titles = ['', '','', '', ''] # TODO: replace, titles for network visualizations
    network_fig_base_path = '' # TODO: replace, where to save the network visualization
    fig_index = 0
    tol = 10**-1 # tolerance parameter for calculating eigenvector centrality

    # Loop through all networks
    for (network_path, network_name, coords_path) in zip(network_paths, network_names, coords_paths):
        if network_name == 'karate':
            network = None # TODO: replace (read in the network); karate club network is weighted
        else:
            network = None # TODO: replace (read in the network); other networks are unweighted

        # Calculating centrality measures
        [degree, betweenness, closeness, eigenvector_centrality, kshell] = get_centrality_measures(network,tol=tol)
        kshell_normalized = kshell/float(max(kshell)) # normalization for easier visualization

        # Scatter plot
        y_values = [betweenness, closeness, eigenvector_centrality, kshell_normalized]
        scatter_path = scatter_base_path + '_' + network_name + '.pdf'
        scatter_fig = plt.figure(fig_index)
        fig_index = fig_index + 1
        create_scatter(degree, 
                       y_values, 
                       x_label, 
                       y_label, 
                       labels, 
                       markers, 
                       scatter_fig,
                       scatter_path)

        # Network figures
        network_fig = plt.figure(fig_index)
        fig_index = fig_index + 1
        network_figure_path = network_fig_base_path + '_' + network_name + '.pdf'
        all_cvalues = [degree, betweenness, closeness, eigenvector_centrality, kshell]
        visualize_on_network(network, 
                             all_cvalues, 
                             network_fig, 
                             titles, 
                             network_figure_path)
